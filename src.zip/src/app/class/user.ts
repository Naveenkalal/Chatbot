
export class User {
    recipient: string | undefined;
    msgBody: string | undefined;
    subject: string | undefined;

    constructor(recipient: string, msgBody: string, subject: string)
    {
        this.recipient = recipient;
        this.msgBody= msgBody;
        this.subject=subject;

    }
}