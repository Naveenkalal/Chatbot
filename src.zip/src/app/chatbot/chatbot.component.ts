import { Component, OnInit } from '@angular/core';
import { Message,ChatService } from '../service/chat.service';
import { formatDate } from '@angular/common';

@Component({
  selector: 'app-chatbot',
  templateUrl: './chatbot.component.html',
  styleUrls: ['./chatbot.component.css']
})
export class ChatbotComponent implements OnInit {
  messages: Message[] = [];
  value!: string;
  today= new Date();
  jstoday = '';

  constructor(public chatService: ChatService) {
    this.jstoday = formatDate(this.today, 'dd-MM-yyyy hh:mm:ss a', 'en-US', '+0530');
   }
  
  ngOnInit() {
      this.chatService.conversation.subscribe((val: any) => {
      this.messages = this.messages.concat(val);
    });
  }

  sendMessage() {
    this.chatService.getBotAnswer(this.value);
    this.value = '';
  }


}
