import { Component, NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { ContactusComponent } from './contactus/contactus.component';
import { ChatbotComponent } from './chatbot/chatbot.component';
import { AboutComponent } from './about/about.component';
import { CareerComponent } from './career/career.component';
import { DeveloperComponent } from './developer/developer.component';
import { DummyComponent } from './dummy/dummy.component';
import { LoginComponent } from './login/login.component';
import { LogoutComponent } from './logout/logout.component';
import { AuthGaurdService } from './service/auth-gaurd.service';

const routes: Routes = [
  {path: 'home', component: HomeComponent },
  {path: '', redirectTo: 'home', pathMatch:'full' },
  {path: 'header', component: HeaderComponent },
  {path: 'footer', component: FooterComponent },
  {path: 'contactus', component: ContactusComponent ,canActivate:[AuthGaurdService]},
  {path:'chatbot', component: ChatbotComponent},
  {path:'about',component:AboutComponent,canActivate:[AuthGaurdService]},
  {path:'career',component:CareerComponent},
  {path:'developer', component:DeveloperComponent},
  {path:'dummy',component:DummyComponent},
  { path: 'login', component: LoginComponent },
  {path:'logout', component:LogoutComponent}
];

@NgModule({
  
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
