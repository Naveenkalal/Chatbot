import { Userotp } from './userotp';

describe('Userotp', () => {
  it('should create an instance', () => {
    expect(new Userotp()).toBeTruthy();
  });
});
