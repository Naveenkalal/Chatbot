export class Userotp {
    otp: string | undefined;

    constructor(otp: string,)
    {
        this.otp = otp;
        

    }
}

