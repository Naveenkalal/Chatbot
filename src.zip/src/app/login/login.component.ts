import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthenticationService } from '../service/authentication.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  cusername = 'Rashmi'
  password = ''
  invalidLogin = false

  constructor(private router: Router, private authenticationService: AuthenticationService) { }

  ngOnInit() {
  }

  checkLogin() {
  //   
  
    // In the login.service.ts we check 
    //   if the valid user is returned by the authentication service. 
    //       If yes then login is successful and the user is forwarded to the employee page.

    //this methods first returns true or flase,,,, but now returning USER object
    this.authenticationService.authenticate(this.cusername, this.password).subscribe(
      data => {
        this.router.navigate([''])
        this.invalidLogin = false
      },
      error => {
        this.invalidLogin = true

      }
    );

  }
 

}
