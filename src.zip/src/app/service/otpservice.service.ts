import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class OtpserviceService {
  private baseUrl = "http://localhost:8080/sendMail";
  private otpurl = "http://localhost:8080/validateOtp";



  headers = new HttpHeaders({
    'Content-type': 'application/json'
  })

  constructor(private httpClient: HttpClient) { }

  getOtpGenerate(user: any): Observable<any> {
    debugger
    const body = JSON.stringify(user);
    return this.httpClient.post(`${this.baseUrl}`, body, { headers: this.headers, responseType: 'text' });
  }

  validateOtp(otp: any): Observable<any> {
    const body = JSON.stringify(otp);
    debugger
    return this.httpClient.post(`${this.otpurl}`, body, { headers: this.headers, responseType: 'text' });

  }

}
