import { HttpHandler, HttpRequest } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class BasicAuthHtppInterceptorService {
//executes for all HttpRequest
intercept(req: HttpRequest<any>, httpHandler: HttpHandler) {

  if (sessionStorage.getItem('username') && sessionStorage.getItem('token')) {
    req = req.clone({
      setHeaders: {
        Authorization: sessionStorage.getItem('token') ?? 'unauthenticated'
      }
    })
  }
  /*
  if (sessionStorage.getItem('username') && sessionStorage.getItem('basicauth')) {
    //adding header to all request
    req = req.clone({
      setHeaders: 
      {
        Authorization: sessionStorage.getItem('basicauth') ?? 'unauthenticated'
      }
    })
  }
  */

  return httpHandler.handle(req);
}
}
