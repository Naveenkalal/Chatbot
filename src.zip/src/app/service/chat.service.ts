import { Injectable } from '@angular/core';

import { Observable, Subject } from 'rxjs';



export interface Message1 {

   author: string;

    content: string;

}

export const message1: Message1[] = [
  {

    "author": "Hi",

    "content": "How can i help you?"

  },
  {

    "author": "We’re here to help! Tell us what you’re looking for and we’ll get you connected to the right people.",

    "content": "Looking for something else?"

  },
  {

    "author":  "What is Angular",

    "content": "Angular is the best framework ever"

  },

  {

    "author": "default",

    "content": "I can't understand. Can you please repeat"

  },

  {

    "author": "bye",

    "content": "get lost"

  }



];



export class Message {

  constructor(public author: string, public content: string) {}

}



@Injectable({

  providedIn: 'root'

})

export class ChatService {



  constructor() {}

 

  conversation = new Subject<Message[]>();

  msg: any = message1;



  messageMap = {

    "Hi": "How can i help you?",

    "We’re here to help! Tell us what you’re looking for and we’ll get you connected to the right people.": "Looking for something else?",

    "What is Angular": "Angular is the best framework ever",

    "default": "I can't understand. Can you please repeat"

  }



  getBotAnswer(msg: string) {

    const userMessage = new Message('user', msg);  

    this.conversation.next([userMessage]);

    const botMessage = new Message('bot', this.getBotMessage(msg));

   

    setTimeout(()=>{

      this.conversation.next([botMessage]);

    }, 1500);

  }



  getBotMessage(question: any){

    let answer;

    answer="dnt no";

     //let ans = this.messageMap[question];

     this.msg.forEach((element: any) => {

 

      console.log(element);

      let tabKey = element.author;

      if(tabKey==question){

       answer = element.content;

      }

    });

     

    return answer;

  }

}