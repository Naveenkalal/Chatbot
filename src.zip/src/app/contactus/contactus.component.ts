import { Component, OnInit } from '@angular/core';
import { OtpserviceService } from '../service/otpservice.service';
import { Router } from '@angular/router';
import { User } from '../class/user';
import { Userotp } from '../otp/userotp';


@Component({
  selector: 'app-contactus',
  templateUrl: './contactus.component.html',
  styleUrls: ['./contactus.component.css']
})
export class ContactusComponent  {

  public email: any;
  public user : any;
  public otp : any;

  constructor(private emailotpService: OtpserviceService,private router : Router) {

  }

  otpGenerate(emailId: string) {
    debugger
    // call the service
    this.email = emailId;
    this.user = new User(`${this.email}`, "Hi User", "One Time Password(OTP)");
    this.emailotpService.getOtpGenerate(this.user).subscribe(res => 
      {
      console.log(res);
        if(res=="Mail Sent Successfully...")
        { 
          //go to next page
          alert("Enter your OTP");
        }
        else{
          alert("Enter valid Email");
        }
    });
  }

  otpValidate(otp: string)
  {
    this.otp = otp;
    this.otp= new Userotp(`${this.otp}`);
    this.emailotpService.validateOtp(this.otp).subscribe(res => 
      {
      console.log(res);
        if(res=="true")
        { 
          //go to next page
          this.router.navigate(['/','chatbot'])
        
        }
        else{
          alert("Invalid Otp");
        }
    });
   
  }

  

}
